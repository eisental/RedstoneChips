/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package org.tal.dependtest;

import org.bukkit.plugin.java.JavaPlugin;

/**
 *
 * @author Tal Eisenberg
 */
public class DependTest extends JavaPlugin {
    public static String x = "defaultvalue";

    public void onDisable() {

    }

    public void onEnable() {
        System.out.println("Enabling DependTest. Static x=" + x);
    }
}
