/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package org.tal.dependenttest;

import org.bukkit.plugin.java.JavaPlugin;
import org.tal.dependtest.DependTest;

/**
 *
 * @author Tal Eisenberg
 */
public class DependentTest extends JavaPlugin {

    public DependentTest() {
        // set a static value in DependTest
        DependTest.x = "someothervalue";
        System.out.println("Setting DependTest.x=" + DependTest.x);
    }

    public void onDisable() {
    }

    public void onEnable() {
        DependTest dependTest = (DependTest)getServer().getPluginManager().getPlugin("DependTest");
        System.out.println("Enabling dependentTest: dependTest=" + dependTest);        
    }

}
