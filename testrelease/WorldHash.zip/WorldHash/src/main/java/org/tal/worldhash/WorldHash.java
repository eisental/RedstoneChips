/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package org.tal.worldhash;

import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

/**
 *
 * @author Tal Eisenberg
 */
public class WorldHash extends JavaPlugin {
    public void onDisable() {

    }

    public void onEnable() {
    }

    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage("Only players are allowed.");
        } else {
            Player p = (Player)sender;
            World a = p.getWorld();
            World b = getServer().getWorld(a.getName());
            p.sendMessage("you.getWorld() = " + a + " (" + a.hashCode() + ").");
            p.sendMessage("getServer().getWorld(\"" + a.getName() + "\") = " + b + " (" + b.hashCode() + ").");
        }

        return true;
    }
}
